const { MongoClient } = require('mongodb');

module.exports = async function (context, req) {
  context.log("Lead dashboard accessed");

  let mongoClient = null;
  
  try {
    // Initialize database connection
    if (!process.env.COSMOS_CONN) {
      context.res = {
        headers: { "Content-Type": "text/html" },
        body: `
          <html>
            <head><title>Lead Dashboard - Database Unavailable</title></head>
            <body>
              <h1>Lead Dashboard</h1>
              <p>Database connection not available (COSMOS_CONN missing).</p>
              <p>No persistent data to display.</p>
            </body>
          </html>
        `
      };
      return;
    }

    mongoClient = new MongoClient(process.env.COSMOS_CONN, {
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000
    });

    await mongoClient.connect();
    const db = mongoClient.db('voiceai'); // Use existing database
    const conversationsCollection = db.collection('conversations');
    const leadsCollection = db.collection('leads');

    // Get recent leads and conversations
    const leads = await leadsCollection.find({})
      .sort({ lastContact: -1 })
      .limit(20)
      .toArray();

    const recentConversations = await conversationsCollection.find({})
      .sort({ timestamp: -1 })
      .limit(10)
      .toArray();

    // Calculate analytics
    const totalLeads = leads.length;
    const emergencyLeads = leads.filter(lead => lead.hasEmergency).length;
    const highScoreLeads = leads.filter(lead => lead.score >= 70).length;
    
    const serviceTypeStats = {};
    leads.forEach(lead => {
      if (lead.serviceType) {
        serviceTypeStats[lead.serviceType] = (serviceTypeStats[lead.serviceType] || 0) + 1;
      }
    });

    const avgScore = totalLeads > 0 ? 
      (leads.reduce((sum, lead) => sum + (lead.score || 0), 0) / totalLeads).toFixed(1) : 0;

    // Generate HTML dashboard
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Voice Agent Lead Dashboard</title>
        <style>
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f5f5f5; 
          }
          .container { max-width: 1200px; margin: 0 auto; }
          .header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; 
            padding: 30px; 
            border-radius: 10px; 
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
          }
          .integration-notice {
            background: #e8f4fd;
            border: 1px solid #bee5eb;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            color: #0c5460;
          }
          .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
          }
          .stat-card { 
            background: white; 
            padding: 25px; 
            border-radius: 10px; 
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
          }
          .stat-number { 
            font-size: 2.5em; 
            font-weight: bold; 
            color: #667eea; 
            margin-bottom: 10px;
          }
          .stat-label { 
            color: #666; 
            font-size: 0.9em; 
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .section { 
            background: white; 
            padding: 25px; 
            border-radius: 10px; 
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .section h2 { 
            color: #333; 
            border-bottom: 2px solid #667eea; 
            padding-bottom: 10px;
            margin-top: 0;
          }
          .lead-item { 
            border: 1px solid #eee; 
            padding: 15px; 
            margin: 10px 0; 
            border-radius: 8px; 
            background: #fafafa;
          }
          .lead-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 10px;
          }
          .phone-number { 
            font-weight: bold; 
            color: #333; 
          }
          .score { 
            padding: 5px 12px; 
            border-radius: 20px; 
            font-weight: bold; 
            color: white;
          }
          .score.high { background: #28a745; }
          .score.medium { background: #ffc107; color: #333; }
          .score.low { background: #dc3545; }
          .emergency { 
            background: #ff4757; 
            color: white; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 0.8em;
            margin-left: 10px;
          }
          .service-type { 
            background: #667eea; 
            color: white; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 0.8em;
            margin-right: 10px;
          }
          .conversation-item { 
            border-left: 4px solid #667eea; 
            padding: 15px; 
            margin: 10px 0; 
            background: #f8f9fa;
            border-radius: 0 8px 8px 0;
          }
          .timestamp { 
            color: #666; 
            font-size: 0.9em; 
          }
          .message-count { 
            color: #667eea; 
            font-weight: bold; 
          }
          .api-example {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            margin-top: 10px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎯 Voice Agent Lead Dashboard</h1>
            <p>Real-time analytics for your AI voice assistant</p>
          </div>

          <div class="integration-notice">
            <h3>🔗 Integration Ready for blucallerai.com</h3>
            <p><strong>This dashboard shows live data from your voice agent.</strong> To integrate with your main application:</p>
            <ul>
              <li><strong>API Access:</strong> Query this Cosmos DB directly from blucallerai.com</li>
              <li><strong>Real-time Webhooks:</strong> Get instant notifications when high-value leads call</li>
              <li><strong>Lead Export:</strong> Bulk export or sync lead data to your existing CRM</li>
            </ul>
          </div>

          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-number">${totalLeads}</div>
              <div class="stat-label">Total Leads</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">${emergencyLeads}</div>
              <div class="stat-label">Emergency Calls</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">${highScoreLeads}</div>
              <div class="stat-label">High-Value Leads</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">${avgScore}</div>
              <div class="stat-label">Average Score</div>
            </div>
          </div>

          <div class="section">
            <h2>📊 Service Type Breakdown</h2>
            ${Object.entries(serviceTypeStats).map(([type, count]) => 
              `<span class="service-type">${type}: ${count}</span>`
            ).join(' ')}
            ${Object.keys(serviceTypeStats).length === 0 ? '<p>No service types recorded yet. Start making test calls!</p>' : ''}
          </div>

          <div class="section">
            <h2>🎯 Recent Leads</h2>
            ${leads.slice(0, 10).map(lead => `
              <div class="lead-item">
                <div class="lead-header">
                  <span class="phone-number">${lead.phoneNumber}</span>
                  <div>
                    ${lead.serviceType ? `<span class="service-type">${lead.serviceType}</span>` : ''}
                    ${lead.hasEmergency ? '<span class="emergency">EMERGENCY</span>' : ''}
                    <span class="score ${lead.score >= 70 ? 'high' : lead.score >= 40 ? 'medium' : 'low'}">
                      ${lead.score}
                    </span>
                  </div>
                </div>
                <div>
                  ${lead.contactInfo?.name ? `<strong>Name:</strong> ${lead.contactInfo.name}<br>` : ''}
                  <strong>Last Contact:</strong> ${new Date(lead.lastContact).toLocaleString()}<br>
                  <strong>Status:</strong> ${lead.urgencyLevel} | <strong>Calls:</strong> ${lead.callHistory?.length || 0}
                </div>
              </div>
            `).join('')}
            ${leads.length === 0 ? '<p>No leads recorded yet. Call your voice agent to generate leads!</p>' : ''}
          </div>

          <div class="section">
            <h2>💬 Recent Conversations</h2>
            ${recentConversations.map(conv => `
              <div class="conversation-item">
                <div class="lead-header">
                  <span class="phone-number">${conv.phoneNumber}</span>
                  <span class="timestamp">${new Date(conv.timestamp).toLocaleString()}</span>
                </div>
                <div>
                  <span class="message-count">${conv.messages?.length || 0} messages</span> |
                  Call ID: ${conv.callSid.substring(0, 10)}... |
                  ${conv.leadInfo?.serviceType ? `Service: ${conv.leadInfo.serviceType}` : 'General inquiry'}
                </div>
              </div>
            `).join('')}
            ${recentConversations.length === 0 ? '<p>No conversations recorded yet. Make a test call to see data here!</p>' : ''}
          </div>

          <div class="section">
            <h2>🔧 Integration Examples</h2>
            <p><strong>API Endpoint for Lead Data:</strong></p>
            <div class="api-example">
              GET https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/lead-dashboard
              // Returns this dashboard as HTML
              
              // For JSON data, create new endpoint:
              GET /api/leads-json → Returns leads as JSON
              GET /api/conversations-json → Returns conversations as JSON
            </div>
            
            <p><strong>Database Connection for blucallerai.com:</strong></p>
            <div class="api-example">
              Database: voiceai
              Collections: conversations, leads
              Connection: Same COSMOS_CONN environment variable
            </div>
          </div>

          <div class="section">
            <h2>🔄 System Status</h2>
            <p>This dashboard refreshes automatically every 30 seconds to show the latest lead data.</p>
            <p><strong>Database:</strong> ✅ Connected to Cosmos DB (voiceai)</p>
            <p><strong>Collections:</strong> ✅ conversations, leads</p>
            <p><strong>Last Updated:</strong> ${new Date().toLocaleString()}</p>
          </div>
        </div>

        <script>
          // Auto-refresh every 30 seconds
          setTimeout(() => {
            location.reload();
          }, 30000);
        </script>
      </body>
      </html>
    `;

    context.res = {
      headers: { "Content-Type": "text/html" },
      body: html
    };

  } catch (error) {
    context.log.error("Dashboard error:", error.message);
    context.res = {
      status: 500,
      headers: { "Content-Type": "text/html" },
      body: `
        <html>
          <head><title>Dashboard Error</title></head>
          <body>
            <h1>Dashboard Error</h1>
            <p>Error loading dashboard: ${error.message}</p>
            <p>Make sure COSMOS_CONN environment variable is properly set.</p>
          </body>
        </html>
      `
    };
  } finally {
    if (mongoClient) {
      try {
        await mongoClient.close();
      } catch (error) {
        context.log.error("Error closing MongoDB connection:", error.message);
      }
    }
  }
}; 