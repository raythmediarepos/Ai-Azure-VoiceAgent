const { MongoClient } = require('mongodb');

class ConversationManager {
  constructor() {
    this.client = null;
    this.db = null;
    this.conversations = null;
    this.leads = null;
    this.isConnected = false;
    this.fallbackMemory = new Map(); // Fallback to in-memory if DB fails
  }

  async initialize() {
    if (this.isConnected) return true;

    try {
      if (!process.env.COSMOS_CONN) {
        console.warn('COSMOS_CONN not found, using fallback memory storage');
        return false;
      }

      this.client = new MongoClient(process.env.COSMOS_CONN, {
        useUnifiedTopology: true,
        serverSelectionTimeoutMS: 5000, // 5 second timeout
        connectTimeoutMS: 5000
      });

      await this.client.connect();
      this.db = this.client.db('voiceagent');
      this.conversations = this.db.collection('conversations');
      this.leads = this.db.collection('leads');
      
      // Create indexes for better performance
      await this.conversations.createIndex({ callSid: 1 });
      await this.conversations.createIndex({ phoneNumber: 1 });
      await this.conversations.createIndex({ timestamp: -1 });
      await this.leads.createIndex({ phoneNumber: 1 });
      await this.leads.createIndex({ score: -1 });
      
      this.isConnected = true;
      console.log('Successfully connected to Cosmos DB');
      return true;
    } catch (error) {
      console.error('Failed to connect to Cosmos DB:', error.message);
      this.isConnected = false;
      return false;
    }
  }

  async getOrCreateSession(callSid, phoneNumber) {
    try {
      // Try database first
      if (this.isConnected) {
        let conversation = await this.conversations.findOne({ callSid });
        
        if (!conversation) {
          // Get previous conversations for this phone number for context
          const previousConversations = await this.conversations
            .find({ phoneNumber })
            .sort({ timestamp: -1 })
            .limit(3)
            .toArray();

          conversation = {
            callSid,
            phoneNumber,
            timestamp: new Date(),
            messages: [{
              role: "system",
              content: this.getSystemPrompt(previousConversations)
            }],
            leadInfo: {
              hasEmergency: false,
              serviceType: null,
              contactInfo: {},
              urgencyLevel: 'normal',
              qualificationScore: 0
            },
            status: 'active'
          };

          await this.conversations.insertOne(conversation);
        }

        return {
          messages: conversation.messages,
          leadInfo: conversation.leadInfo,
          callSid: conversation.callSid
        };
      }
    } catch (error) {
      console.error('Database error in getOrCreateSession:', error.message);
    }

    // Fallback to memory
    if (!this.fallbackMemory.has(callSid)) {
      this.fallbackMemory.set(callSid, {
        messages: [{
          role: "system",
          content: this.getSystemPrompt([])
        }],
        leadInfo: {
          hasEmergency: false,
          serviceType: null,
          contactInfo: {},
          urgencyLevel: 'normal',
          qualificationScore: 0
        },
        callSid
      });
    }

    return this.fallbackMemory.get(callSid);
  }

  getSystemPrompt(previousConversations) {
    const hasHistory = previousConversations && previousConversations.length > 0;
    
    let contextInfo = "";
    if (hasHistory) {
      const lastCall = previousConversations[0];
      contextInfo = `\n\nNote: This caller has contacted us before. Last conversation was on ${lastCall.timestamp.toDateString()}. `;
      
      if (lastCall.leadInfo?.serviceType) {
        contextInfo += `They previously inquired about ${lastCall.leadInfo.serviceType}. `;
      }
      
      if (lastCall.leadInfo?.contactInfo?.name) {
        contextInfo += `Their name is ${lastCall.leadInfo.contactInfo.name}. `;
      }
    }

    return `You are a professional HVAC service representative for a heating and air conditioning company. Your goals:

1. HELP CUSTOMERS: Provide helpful information about HVAC services, troubleshooting, and scheduling
2. GATHER INFORMATION: Naturally collect contact details and assess their needs
3. QUALIFY LEADS: Determine urgency, service type needed, and schedule callbacks
4. BE CONVERSATIONAL: Keep responses to 1-2 sentences, sound natural and helpful

IMPORTANT SCENARIOS:
- EMERGENCY (no heat/AC, gas smell, electrical issues): Immediately offer same-day service
- ROUTINE (maintenance, estimates, non-urgent repairs): Gather info for follow-up
- INFORMATION (general questions): Provide helpful answers and check if they need services

Always be professional but friendly. If they mention their name, address, or phone number, acknowledge it naturally. Ask one relevant follow-up question per response.${contextInfo}`;
  }

  async addMessage(callSid, message) {
    try {
      // Try database first
      if (this.isConnected) {
        await this.conversations.updateOne(
          { callSid },
          { 
            $push: { messages: message },
            $set: { lastActivity: new Date() }
          }
        );
        
        // Analyze the conversation after each message
        if (message.role === 'user') {
          await this.analyzeMessage(callSid, message.content);
        }
        
        return true;
      }
    } catch (error) {
      console.error('Database error in addMessage:', error.message);
    }

    // Fallback to memory
    const session = this.fallbackMemory.get(callSid);
    if (session) {
      session.messages.push(message);
    }
    
    return false;
  }

  async analyzeMessage(callSid, messageContent) {
    try {
      const conversation = await this.conversations.findOne({ callSid });
      if (!conversation) return;

      const analysis = this.performBusinessIntelligence(messageContent);
      const updatedLeadInfo = { ...conversation.leadInfo };

      // Update lead information based on analysis
      if (analysis.hasEmergency) updatedLeadInfo.hasEmergency = true;
      if (analysis.serviceType) updatedLeadInfo.serviceType = analysis.serviceType;
      if (analysis.urgencyLevel) updatedLeadInfo.urgencyLevel = analysis.urgencyLevel;
      if (analysis.contactInfo) {
        updatedLeadInfo.contactInfo = { ...updatedLeadInfo.contactInfo, ...analysis.contactInfo };
      }

      // Calculate qualification score
      updatedLeadInfo.qualificationScore = this.calculateLeadScore(updatedLeadInfo);

      await this.conversations.updateOne(
        { callSid },
        { $set: { leadInfo: updatedLeadInfo } }
      );

      // Create or update lead record
      await this.updateLeadRecord(conversation.phoneNumber, updatedLeadInfo, callSid);

    } catch (error) {
      console.error('Error in conversation analysis:', error.message);
    }
  }

  performBusinessIntelligence(message) {
    const lowerMessage = message.toLowerCase();
    const analysis = {
      hasEmergency: false,
      serviceType: null,
      urgencyLevel: 'normal',
      contactInfo: {}
    };

    // Emergency detection
    const emergencyKeywords = ['emergency', 'urgent', 'no heat', 'no air', 'not working', 'broken', 'gas smell', 'electrical', 'flooding', 'leak'];
    if (emergencyKeywords.some(keyword => lowerMessage.includes(keyword))) {
      analysis.hasEmergency = true;
      analysis.urgencyLevel = 'emergency';
    }

    // Service type detection
    const serviceTypes = {
      'heating': ['heat', 'heating', 'furnace', 'boiler', 'warm'],
      'cooling': ['cool', 'cooling', 'air conditioning', 'ac', 'cold'],
      'maintenance': ['maintenance', 'service', 'tune up', 'check', 'inspect'],
      'installation': ['install', 'new', 'replace', 'replacement'],
      'repair': ['repair', 'fix', 'broken', 'not working']
    };

    for (const [type, keywords] of Object.entries(serviceTypes)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        analysis.serviceType = type;
        break;
      }
    }

    // Extract potential contact information
    const nameMatch = message.match(/(?:my name is|i'm|i am)\s+([a-z]+(?:\s+[a-z]+)?)/i);
    if (nameMatch) {
      analysis.contactInfo.name = nameMatch[1].trim();
    }

    const phoneMatch = message.match(/(\d{3}[-.]?\d{3}[-.]?\d{4})/);
    if (phoneMatch) {
      analysis.contactInfo.phone = phoneMatch[1];
    }

    return analysis;
  }

  calculateLeadScore(leadInfo) {
    let score = 0;

    // Base score for any interaction
    score += 10;

    // Emergency = high value
    if (leadInfo.hasEmergency) score += 50;

    // Service type scoring
    const serviceScores = {
      'installation': 40,
      'heating': 30,
      'cooling': 30,
      'repair': 25,
      'maintenance': 15
    };
    if (leadInfo.serviceType && serviceScores[leadInfo.serviceType]) {
      score += serviceScores[leadInfo.serviceType];
    }

    // Contact information provided
    if (leadInfo.contactInfo.name) score += 15;
    if (leadInfo.contactInfo.phone) score += 20;

    // Urgency level
    if (leadInfo.urgencyLevel === 'emergency') score += 30;
    else if (leadInfo.urgencyLevel === 'high') score += 15;

    return Math.min(score, 100); // Cap at 100
  }

  async updateLeadRecord(phoneNumber, leadInfo, callSid) {
    try {
      const existingLead = await this.leads.findOne({ phoneNumber });
      
      if (existingLead) {
        // Update existing lead with new information
        await this.leads.updateOne(
          { phoneNumber },
          { 
            $set: {
              lastContact: new Date(),
              score: Math.max(existingLead.score || 0, leadInfo.qualificationScore),
              hasEmergency: existingLead.hasEmergency || leadInfo.hasEmergency,
              serviceType: leadInfo.serviceType || existingLead.serviceType,
              contactInfo: { ...existingLead.contactInfo, ...leadInfo.contactInfo },
              urgencyLevel: this.getHighestUrgency(existingLead.urgencyLevel, leadInfo.urgencyLevel)
            },
            $addToSet: { callHistory: callSid }
          }
        );
      } else {
        // Create new lead
        await this.leads.insertOne({
          phoneNumber,
          firstContact: new Date(),
          lastContact: new Date(),
          score: leadInfo.qualificationScore,
          hasEmergency: leadInfo.hasEmergency,
          serviceType: leadInfo.serviceType,
          contactInfo: leadInfo.contactInfo,
          urgencyLevel: leadInfo.urgencyLevel,
          callHistory: [callSid],
          status: 'new'
        });
      }
    } catch (error) {
      console.error('Error updating lead record:', error.message);
    }
  }

  getHighestUrgency(existing, current) {
    const urgencyLevels = { 'emergency': 3, 'high': 2, 'normal': 1 };
    const existingLevel = urgencyLevels[existing] || 1;
    const currentLevel = urgencyLevels[current] || 1;
    
    const highestLevel = Math.max(existingLevel, currentLevel);
    return Object.keys(urgencyLevels).find(key => urgencyLevels[key] === highestLevel);
  }

  async getConversationHistory(phoneNumber, limit = 5) {
    try {
      if (this.isConnected) {
        return await this.conversations
          .find({ phoneNumber })
          .sort({ timestamp: -1 })
          .limit(limit)
          .toArray();
      }
    } catch (error) {
      console.error('Error getting conversation history:', error.message);
    }
    return [];
  }

  async getLeadInfo(phoneNumber) {
    try {
      if (this.isConnected) {
        return await this.leads.findOne({ phoneNumber });
      }
    } catch (error) {
      console.error('Error getting lead info:', error.message);
    }
    return null;
  }

  async cleanup() {
    try {
      if (this.client) {
        await this.client.close();
        this.isConnected = false;
      }
    } catch (error) {
      console.error('Error closing database connection:', error.message);
    }
  }
}

// Export singleton instance
const conversationManager = new ConversationManager();

module.exports = conversationManager; 