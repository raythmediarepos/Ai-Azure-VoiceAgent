const { OpenAIClient, AzureKeyCredential } = require("@azure/openai");
const querystring = require('querystring');
const { MongoClient } = require('mongodb');

// Initialize Azure OpenAI with API key
const openai = new OpenAIClient(
  process.env.OPENAI_ENDPOINT,
  new AzureKeyCredential(process.env.OPENAI_KEY)
);

// Database connection
let mongoClient = null;
let db = null;
let conversationsCollection = null;
let leadsCollection = null;
let isDbConnected = false;

// Store conversation sessions (fallback)
const conversationSessions = new Map();

// Initialize database connection
const initializeDatabase = async (context) => {
  if (isDbConnected) return true;
  
  try {
    if (!process.env.COSMOS_CONN) {
      context.log.warn('COSMOS_CONN not found, using memory storage');
      return false;
    }

    mongoClient = new MongoClient(process.env.COSMOS_CONN, {
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000
    });

    await mongoClient.connect();
    db = mongoClient.db('voiceai'); // Use existing database
    conversationsCollection = db.collection('conversations');
    leadsCollection = db.collection('leads');
    
    // Create indexes for better performance
    await conversationsCollection.createIndex({ callSid: 1 });
    await conversationsCollection.createIndex({ phoneNumber: 1 });
    await conversationsCollection.createIndex({ timestamp: -1 });
    await leadsCollection.createIndex({ phoneNumber: 1 });
    await leadsCollection.createIndex({ score: -1 });
    
    isDbConnected = true;
    context.log('Successfully connected to Cosmos DB (voiceai database)');
    return true;
  } catch (error) {
    context.log.error('Failed to connect to Cosmos DB:', error.message);
    isDbConnected = false;
    return false;
  }
};

// Helper function to get or create conversation session
const getOrCreateSession = async (callSid, phoneNumber, context) => {
  // Try database first
  if (isDbConnected) {
    try {
      let conversation = await conversationsCollection.findOne({ callSid });
      
      if (!conversation) {
        // Get previous conversations for context
        const previousConversations = await conversationsCollection
          .find({ phoneNumber })
          .sort({ timestamp: -1 })
          .limit(3)
          .toArray();

        const hasHistory = previousConversations && previousConversations.length > 0;
        let contextInfo = "";
        
        if (hasHistory) {
          const lastCall = previousConversations[0];
          contextInfo = `\n\nNote: This caller has contacted us before. Last conversation was on ${lastCall.timestamp.toDateString()}. `;
          
          if (lastCall.leadInfo?.serviceType) {
            contextInfo += `They previously inquired about ${lastCall.leadInfo.serviceType}. `;
          }
          
          if (lastCall.leadInfo?.contactInfo?.name) {
            contextInfo += `Their name is ${lastCall.leadInfo.contactInfo.name}. `;
          }
        }

        conversation = {
          callSid,
          phoneNumber,
          timestamp: new Date(),
          messages: [{
            role: "system",
            content: `You are a professional HVAC service representative for a heating and air conditioning company. Your goals:

1. HELP CUSTOMERS: Provide helpful information about HVAC services, troubleshooting, and scheduling
2. GATHER INFORMATION: Naturally collect contact details and assess their needs
3. QUALIFY LEADS: Determine urgency, service type needed, and schedule callbacks
4. BE CONVERSATIONAL: Keep responses to 1-2 sentences, sound natural and helpful

IMPORTANT SCENARIOS:
- EMERGENCY (no heat/AC, gas smell, electrical issues): Immediately offer same-day service
- ROUTINE (maintenance, estimates, non-urgent repairs): Gather info for follow-up
- INFORMATION (general questions): Provide helpful answers and check if they need services

Always be professional but friendly. If they mention their name, address, or phone number, acknowledge it naturally. Ask one relevant follow-up question per response.${contextInfo}`
          }],
          leadInfo: {
            hasEmergency: false,
            serviceType: null,
            contactInfo: {},
            urgencyLevel: 'normal',
            qualificationScore: 0
          },
          status: 'active'
        };

        await conversationsCollection.insertOne(conversation);
        context.log('Created new conversation in database');
      }

      return {
        messages: conversation.messages,
        leadInfo: conversation.leadInfo,
        callSid: conversation.callSid,
        isFromDb: true
      };
    } catch (error) {
      context.log.error('Database error in getOrCreateSession:', error.message);
    }
  }

  // Fallback to memory
  if (!conversationSessions.has(callSid)) {
    conversationSessions.set(callSid, {
      messages: [{
        role: "system",
        content: "You are a professional HVAC service representative for a heating and air conditioning company. Keep your responses conversational, concise (1-2 sentences), and natural for spoken conversation. You're talking to someone over the phone. Help customers with HVAC services, troubleshooting, and scheduling."
      }],
      leadInfo: {
        hasEmergency: false,
        serviceType: null,
        contactInfo: {},
        urgencyLevel: 'normal',
        qualificationScore: 0
      },
      callSid,
      isFromDb: false
    });
    context.log('Created new conversation in memory (fallback)');
  }

  return conversationSessions.get(callSid);
};

// Add message to conversation
const addMessage = async (callSid, message, context) => {
  try {
    if (isDbConnected) {
      await conversationsCollection.updateOne(
        { callSid },
        { 
          $push: { messages: message },
          $set: { lastActivity: new Date() }
        }
      );
      
      // Analyze the conversation after user messages
      if (message.role === 'user') {
        await analyzeAndUpdateLead(callSid, message.content, context);
      }
      
      return true;
    }
  } catch (error) {
    context.log.error('Database error in addMessage:', error.message);
  }

  // Fallback to memory
  const session = conversationSessions.get(callSid);
  if (session) {
    session.messages.push(message);
  }
  
  return false;
};

// Analyze conversation and update lead
const analyzeAndUpdateLead = async (callSid, messageContent, context) => {
  try {
    const conversation = await conversationsCollection.findOne({ callSid });
    if (!conversation) return;

    const analysis = performBusinessIntelligence(messageContent);
    const updatedLeadInfo = { ...conversation.leadInfo };

    // Update lead information based on analysis
    if (analysis.hasEmergency) updatedLeadInfo.hasEmergency = true;
    if (analysis.serviceType) updatedLeadInfo.serviceType = analysis.serviceType;
    if (analysis.urgencyLevel) updatedLeadInfo.urgencyLevel = analysis.urgencyLevel;
    if (analysis.contactInfo) {
      updatedLeadInfo.contactInfo = { ...updatedLeadInfo.contactInfo, ...analysis.contactInfo };
    }

    // Calculate qualification score
    updatedLeadInfo.qualificationScore = calculateLeadScore(updatedLeadInfo);

    await conversationsCollection.updateOne(
      { callSid },
      { $set: { leadInfo: updatedLeadInfo } }
    );

    // Update lead record
    await updateLeadRecord(conversation.phoneNumber, updatedLeadInfo, callSid, context);

  } catch (error) {
    context.log.error('Error in conversation analysis:', error.message);
  }
};

// Business intelligence analysis
const performBusinessIntelligence = (message) => {
  const lowerMessage = message.toLowerCase();
  const analysis = {
    hasEmergency: false,
    serviceType: null,
    urgencyLevel: 'normal',
    contactInfo: {}
  };

  // Emergency detection
  const emergencyKeywords = ['emergency', 'urgent', 'no heat', 'no air', 'not working', 'broken', 'gas smell', 'electrical', 'flooding', 'leak'];
  if (emergencyKeywords.some(keyword => lowerMessage.includes(keyword))) {
    analysis.hasEmergency = true;
    analysis.urgencyLevel = 'emergency';
  }

  // Service type detection
  const serviceTypes = {
    'heating': ['heat', 'heating', 'furnace', 'boiler', 'warm'],
    'cooling': ['cool', 'cooling', 'air conditioning', 'ac', 'cold'],
    'maintenance': ['maintenance', 'service', 'tune up', 'check', 'inspect'],
    'installation': ['install', 'new', 'replace', 'replacement'],
    'repair': ['repair', 'fix', 'broken', 'not working']
  };

  for (const [type, keywords] of Object.entries(serviceTypes)) {
    if (keywords.some(keyword => lowerMessage.includes(keyword))) {
      analysis.serviceType = type;
      break;
    }
  }

  // Extract contact information
  const nameMatch = message.match(/(?:my name is|i'm|i am)\s+([a-z]+(?:\s+[a-z]+)?)/i);
  if (nameMatch) {
    analysis.contactInfo.name = nameMatch[1].trim();
  }

  const phoneMatch = message.match(/(\d{3}[-.]?\d{3}[-.]?\d{4})/);
  if (phoneMatch) {
    analysis.contactInfo.phone = phoneMatch[1];
  }

  return analysis;
};

// Calculate lead score
const calculateLeadScore = (leadInfo) => {
  let score = 10; // Base score

  if (leadInfo.hasEmergency) score += 50;
  
  const serviceScores = {
    'installation': 40,
    'heating': 30,
    'cooling': 30,
    'repair': 25,
    'maintenance': 15
  };
  if (leadInfo.serviceType && serviceScores[leadInfo.serviceType]) {
    score += serviceScores[leadInfo.serviceType];
  }

  if (leadInfo.contactInfo.name) score += 15;
  if (leadInfo.contactInfo.phone) score += 20;

  if (leadInfo.urgencyLevel === 'emergency') score += 30;
  else if (leadInfo.urgencyLevel === 'high') score += 15;

  return Math.min(score, 100);
};

// Update lead record
const updateLeadRecord = async (phoneNumber, leadInfo, callSid, context) => {
  try {
    const existingLead = await leadsCollection.findOne({ phoneNumber });
    
    if (existingLead) {
      await leadsCollection.updateOne(
        { phoneNumber },
        { 
          $set: {
            lastContact: new Date(),
            score: Math.max(existingLead.score || 0, leadInfo.qualificationScore),
            hasEmergency: existingLead.hasEmergency || leadInfo.hasEmergency,
            serviceType: leadInfo.serviceType || existingLead.serviceType,
            contactInfo: { ...existingLead.contactInfo, ...leadInfo.contactInfo },
            urgencyLevel: getHighestUrgency(existingLead.urgencyLevel, leadInfo.urgencyLevel)
          },
          $addToSet: { callHistory: callSid }
        }
      );
    } else {
      await leadsCollection.insertOne({
        phoneNumber,
        firstContact: new Date(),
        lastContact: new Date(),
        score: leadInfo.qualificationScore,
        hasEmergency: leadInfo.hasEmergency,
        serviceType: leadInfo.serviceType,
        contactInfo: leadInfo.contactInfo,
        urgencyLevel: leadInfo.urgencyLevel,
        callHistory: [callSid],
        status: 'new'
      });
    }
    context.log('Lead record updated successfully');
  } catch (error) {
    context.log.error('Error updating lead record:', error.message);
  }
};

const getHighestUrgency = (existing, current) => {
  const urgencyLevels = { 'emergency': 3, 'high': 2, 'normal': 1 };
  const existingLevel = urgencyLevels[existing] || 1;
  const currentLevel = urgencyLevels[current] || 1;
  
  const highestLevel = Math.max(existingLevel, currentLevel);
  return Object.keys(urgencyLevels).find(key => urgencyLevels[key] === highestLevel);
};

// Function to get AI response from Azure OpenAI
const getAIResponse = async (messages) => {
  try {
    const completion = await openai.getChatCompletions(
      "gpt-35-turbo", // Your deployment name
      messages,
      {
        maxTokens: 150,
        temperature: 0.7
      }
    );
    
    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Azure OpenAI error:", error);
    return "I'm sorry, I'm having trouble processing that right now. Could you try again?";
  }
};

module.exports = async function (context, req) {
  context.log("VOICE-STREAM FUNCTION CALLED!");
  context.log("Request Method:", req.method);
  
  // Initialize database
  const dbConnected = await initializeDatabase(context);
  
  try {
    // Handle Twilio speech recognition results
    if (req.method === "POST" && req.body) {
      // Parse URL-encoded form data from Twilio
      const formData = typeof req.body === 'string' ? querystring.parse(req.body) : req.body;
      
      const speechResult = formData.SpeechResult;
      const callSid = formData.CallSid;
      const phoneNumber = formData.From; // Caller's phone number
      const confidence = parseFloat(formData.Confidence || 0);
      
      context.log("Speech Result:", speechResult);
      context.log("Call SID:", callSid);
      context.log("Phone Number:", phoneNumber);
      context.log("Confidence:", confidence);
      context.log("Database Status:", dbConnected ? "Connected" : "Memory fallback");
      
      // Filter out low-confidence results
      if (confidence < 0.5 && speechResult && speechResult.trim().length < 5) {
        context.log("Low confidence speech result, asking for clarification");
        
        const clarificationTwiml = `
          <Response>
            <Say voice="en-US-JennyNeural">I didn't quite catch that. Could you please repeat what you need help with?</Say>
            <Gather input="speech" timeout="30" speechTimeout="auto" action="https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-stream" method="POST">
              <Say voice="en-US-JennyNeural">I'm listening...</Say>
            </Gather>
            <Redirect>https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-twiml</Redirect>
          </Response>
        `.trim();
        
        context.res = {
          headers: { "Content-Type": "text/xml" },
          body: clarificationTwiml
        };
        return;
      }
      
      if (speechResult && speechResult.trim().length > 0) {
        // Get or create session
        const session = await getOrCreateSession(callSid, phoneNumber, context);
        
        context.log("Session retrieved, current message count:", session.messages.length);
        context.log("Session source:", session.isFromDb ? "Database" : "Memory");
        
        // Add user message to conversation
        const userMessage = {
          role: "user",
          content: speechResult
        };
        
        session.messages.push(userMessage);
        await addMessage(callSid, userMessage, context);
        
        context.log("Getting AI response for:", speechResult);
        
        // Get AI response
        const aiResponse = await getAIResponse(session.messages);
        context.log("AI Response:", aiResponse);
        
        // Add AI response to conversation
        const assistantMessage = {
          role: "assistant",
          content: aiResponse
        };
        
        session.messages.push(assistantMessage);
        await addMessage(callSid, assistantMessage, context);
        
        // Determine follow-up based on analysis
        let followUpPrompt = "What else can I help you with?";
        
        if (session.leadInfo?.hasEmergency) {
          followUpPrompt = "This sounds urgent. Can I get your name and address to dispatch a technician?";
        } else if (session.leadInfo?.serviceType && !session.leadInfo?.contactInfo?.name) {
          followUpPrompt = "I'd like to help you further. May I get your name and phone number for our records?";
        }
        
        // Return TwiML with AI response and continue listening
        const responseTwiml = `
          <Response>
            <Say voice="en-US-JennyNeural">${aiResponse}</Say>
            <Gather input="speech" timeout="30" speechTimeout="auto" action="https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-stream" method="POST">
              <Say voice="en-US-JennyNeural">${followUpPrompt}</Say>
            </Gather>
            <Redirect>https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-twiml</Redirect>
          </Response>
        `.trim();
        
        context.res = {
          headers: { "Content-Type": "text/xml" },
          body: responseTwiml
        };
        return;
      } else {
        // No speech detected, try again
        const noSpeechTwiml = `
          <Response>
            <Say voice="en-US-JennyNeural">I didn't hear anything. Could you please tell me how I can help you today?</Say>
            <Gather input="speech" timeout="30" speechTimeout="auto" action="https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-stream" method="POST">
              <Say voice="en-US-JennyNeural">I'm listening...</Say>
            </Gather>
            <Redirect>https://func-blucallerai-dkavgbhvdkesgmer.westus-01.azurewebsites.net/api/voice-twiml</Redirect>
          </Response>
        `.trim();
        
        context.res = {
          headers: { "Content-Type": "text/xml" },
          body: noSpeechTwiml
        };
        return;
      }
    }
    
    // Default response for other requests
    context.res = { 
      status: 200,
      body: "Voice stream endpoint ready with Cosmos DB integration"
    };
    
  } catch (error) {
    context.log.error("Function error:", error.message);
    context.log.error("Stack trace:", error.stack);
    
    // Error TwiML
    const errorTwiml = `
      <Response>
        <Say voice="en-US-JennyNeural">I'm sorry, I encountered an error. Please try calling again.</Say>
        <Hangup />
      </Response>
    `.trim();
    
    context.res = { 
      status: 200,
      headers: { "Content-Type": "text/xml" },
      body: errorTwiml
    };
  }
};
